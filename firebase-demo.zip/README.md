## How to use this repository

This repository is meant to be used with the [Building a web application with Angular and Firebase](https://codelabs.developers.google.com/codelabs/building-a-web-app-with-angular-and-firebase).

## How to make contributions?

Please read and follow the steps in the [CONTRIBUTING.md](CONTRIBUTING.md).

## License

See [LICENSE](LICENSE).
