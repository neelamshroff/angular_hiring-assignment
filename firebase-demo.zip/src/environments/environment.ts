// This file can be replaced during build by using the `fileReplacements` array.
// `ng build --prod` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.

export const environment = {
  production: false,
  firebase: {
    apiKey: "AIzaSyAMFXMyTB8pjTq5Lyb_gUqYqs9Tf4JFyVQ",
    authDomain: "fir-demo-6a1b6.firebaseapp.com",
    projectId: "fir-demo-6a1b6",
    storageBucket: "fir-demo-6a1b6.appspot.com",
    messagingSenderId: "1051099231857",
    appId: "1:1051099231857:web:ff59a11cf4527a67368dd0",
    measurementId: "G-PP5DM0H27F",
    databaseURL: 'https://fir-demo-6a1b6.firebaseio.com'
  }
};