import { Component } from '@angular/core';
import { AngularFirestore, AngularFirestoreCollection } from '@angular/fire/firestore';
import { BehaviorSubject, Observable } from 'rxjs';

const getObservable = (collection: AngularFirestoreCollection<Users>) => {
  const subject = new BehaviorSubject<Users[]>([]);
  collection.valueChanges({ idField: 'id' }).subscribe((val: Users[]) => {
    subject.next(val);
  });
  return subject;
};

export interface Users {
  id: string
  name: string;
  mail: string;
  disabled: boolean;
  roles: string[];
}

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
})
export class AppComponent {
  

  displayedColumns: string[] = ['name', 'mail', 'roles', 'disabled'];
  users: Observable<Users[]> = getObservable(this.store.collection('users'));
  isLoadingResults = true;
  isRateLimitReached = false;

  constructor(private store: AngularFirestore) {

    this.users.subscribe((data: any) => {
        console.log("Data from firebase: ", data);
    });
  }

  updateStatus(user : Users ){
    user.disabled = !user.disabled;
    this.store.collection("users").doc(user.id).update(user);
  }
}
